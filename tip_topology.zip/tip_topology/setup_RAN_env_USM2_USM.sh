# Load file
#!/usr/bin/env bash

########################################################################################################################
export hostname=nfv127
export router_id=1.1.1.14
export dcsg_type=CE
export api_payload='input-source'
export api_port=9091
export api_url='/tip/v1/CreateNE/oss/ne/'
export bgp_number_of_neighbors=0
